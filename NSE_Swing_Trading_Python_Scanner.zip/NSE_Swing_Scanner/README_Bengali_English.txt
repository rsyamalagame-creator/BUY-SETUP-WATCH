# NSE ATH Retest Swing Trading Scanner

## 1) Install packages (Windows)
Open Command Prompt in this folder and run:

```bash
py -m pip install -r requirements.txt
```

If `py` does not work, try `python -m pip install -r requirements.txt`.

## 2) Add NSE symbols
Open `data/nse_symbols.csv` in Notepad or Excel. Add one NSE trading symbol per row under the `Symbol` heading.
Examples: `RELIANCE`, `TCS`, `INFY`. Do not add `.NS`.

The starter file contains only a few sample symbols. Replace/add the symbols you want to scan.
This scanner does NOT automatically download a complete official NSE stock universe list.

## 3) Run a small test first
```bash
py nse_swing_scanner.py --limit 8
```

## 4) Run all symbols in your CSV
```bash
py nse_swing_scanner.py
```

The report is saved in the `output` folder as a dated CSV file. Open it with Excel or Google Sheets.

## Strategy used
- Close > 20 DMA > 50 DMA
- RSI(14) from 50 to 65
- Latest volume / 20-day average volume >= 1.5
- A recent daily close breakout above the prior lifetime high
- Subsequent rise from breakout level of 5% to 50%
- Retest near breakout level (within a 3% band)
- Bullish reversal candle at retest for BUY WATCH
- BUY CONFIRMATION requires a later close above the prior candle high, with trend/RSI/volume checks

Bullish RSI divergence is calculated as an extra column, not a mandatory condition.

## Important limitations
- Uses Yahoo Finance through `yfinance`, not a guaranteed official NSE live feed.
- Data can be delayed, missing, adjusted, or inconsistent for some symbols.
- The script is intended to run after the market closes; during market hours the latest candle may be incomplete.
- ATH breakout/retest detection is a mechanical approximation. Check the chart manually before considering any trade.
- Stop-loss reference uses the lowest low of the last 10 sessions as a simple reference; verify the actual swing low.
- No automatic order placement. This is a research/watchlist tool, not investment advice.

## Troubleshooting
- `No module named yfinance`: run `py -m pip install -r requirements.txt`.
- `nse_symbols.csv not found`: keep the `data` folder and CSV next to the Python script.
- No results: this means no symbols in your CSV met every filter, or the data provider did not return enough data. Check the failed-symbols text file.
