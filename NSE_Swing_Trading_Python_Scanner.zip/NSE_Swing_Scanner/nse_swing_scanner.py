"""
NSE ATH Retest Swing Trading Scanner
Educational/watchlist tool only. Not financial advice.

Data source: Yahoo Finance via yfinance (unofficial; may be delayed, incomplete,
or unavailable for some NSE symbols). Verify every candidate on your broker/chart.
"""

from __future__ import annotations

import argparse
import logging
import time
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
import yfinance as yf

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

DATA_DIR = Path("data")
OUTPUT_DIR = Path("output")
SYMBOL_FILE = DATA_DIR / "nse_symbols.csv"


def load_symbols(limit: Optional[int] = None) -> list[str]:
    """Read NSE symbols from data/nse_symbols.csv; one column named Symbol."""
    if not SYMBOL_FILE.exists():
        raise FileNotFoundError(
            f"{SYMBOL_FILE} not found. Create it with a column named Symbol "
            "and NSE symbols such as RELIANCE, TCS, INFY."
        )
    frame = pd.read_csv(SYMBOL_FILE)
    if "Symbol" not in frame.columns:
        raise ValueError("CSV must contain a column named 'Symbol'.")
    symbols = (
        frame["Symbol"].dropna().astype(str).str.strip().str.upper()
        .str.replace(r"\.NS$", "", regex=True)
    )
    symbols = [s for s in symbols.unique() if s and s != "NAN"]
    return symbols[:limit] if limit else symbols


def download_history(symbol: str, period: str = "max") -> pd.DataFrame:
    ticker = f"{symbol}.NS"
    data = yf.download(
        ticker, period=period, interval="1d", auto_adjust=True,
        progress=False, threads=False
    )
    if data is None or data.empty:
        return pd.DataFrame()
    # yfinance may return MultiIndex columns, depending on version.
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)
    required = {"Open", "High", "Low", "Close", "Volume"}
    if not required.issubset(set(data.columns)):
        return pd.DataFrame()
    data = data[list(required)].copy()
    data = data.dropna(subset=["Open", "High", "Low", "Close"])
    data = data[~data.index.duplicated(keep="last")].sort_index()
    return data


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    result = 100 - (100 / (1 + rs))
    return result.fillna(100).where(avg_loss.ne(0), 100)


def has_bullish_rsi_divergence(df: pd.DataFrame, lookback: int = 60) -> bool:
    """Simple pivot-low divergence: recent price low lower, RSI low higher."""
    part = df.tail(lookback).copy()
    if len(part) < 20:
        return False
    lows = part["Low"].to_numpy()
    rsi_values = part["RSI"].to_numpy()
    pivots = []
    for i in range(2, len(part) - 2):
        if lows[i] <= min(lows[i-2:i]) and lows[i] < min(lows[i+1:i+3]):
            pivots.append(i)
    if len(pivots) < 2:
        return False
    p1, p2 = pivots[-2], pivots[-1]
    return bool(lows[p2] < lows[p1] and rsi_values[p2] > rsi_values[p1])


def find_latest_breakout(df: pd.DataFrame, max_age: int = 252):
    """
    Find latest daily close crossing above the previous lifetime high.
    Return (position, breakout_level). Use history before breakout only.
    """
    start = max(1, len(df) - max_age)
    for i in range(len(df) - 2, start - 1, -1):
        prior_ath = float(df["High"].iloc[:i].max())
        previous_close = float(df["Close"].iloc[i - 1])
        current_close = float(df["Close"].iloc[i])
        if previous_close <= prior_ath and current_close > prior_ath:
            return i, prior_ath
    return None, None


def analyze_symbol(symbol: str, df: pd.DataFrame) -> Optional[dict]:
    if len(df) < 260:
        return None

    df = df.copy()
    df["DMA20"] = df["Close"].rolling(20).mean()
    df["DMA50"] = df["Close"].rolling(50).mean()
    df["RSI"] = rsi(df["Close"], 14)
    df["AvgVol20"] = df["Volume"].rolling(20).mean()
    df["VolRatio"] = df["Volume"] / df["AvgVol20"]

    # Use last completed daily candle; data provider can occasionally return
    # an in-progress candle during market hours, so run after market close.
    latest = df.iloc[-1]
    previous = df.iloc[-2]
    close = float(latest["Close"])
    high = float(latest["High"])
    low = float(latest["Low"])
    open_ = float(latest["Open"])
    dma20 = float(latest["DMA20"])
    dma50 = float(latest["DMA50"])
    rsi_now = float(latest["RSI"])
    vol_ratio = float(latest["VolRatio"]) if pd.notna(latest["VolRatio"]) else 0.0

    trend_ok = close > dma20 > dma50
    rsi_ok = 50 <= rsi_now <= 65
    volume_ok = vol_ratio >= 1.5

    breakout_pos, breakout_level = find_latest_breakout(df.iloc[:-1])
    if breakout_pos is None:
        return None

    after_breakout = df.iloc[breakout_pos:-1]
    if after_breakout.empty:
        return None
    peak_after_breakout = float(after_breakout["High"].max())
    rise_pct = (peak_after_breakout / breakout_level - 1) * 100
    if not (5 <= rise_pct <= 50):
        return None

    # Retest zone: daily low within 3% of the former ATH; close must not
    # finish more than 3% below that level.
    retest_ok = (
        low <= breakout_level * 1.03
        and low >= breakout_level * 0.97
        and close >= breakout_level * 0.97
    )

    # A basic bullish reversal candle: green candle and close above prior close.
    reversal_ok = close > open_ and close > float(previous["Close"])
    divergence = has_bullish_rsi_divergence(df)

    watch = all([trend_ok, rsi_ok, volume_ok, retest_ok, reversal_ok])
    # Confirmation is a later close above the previous candle's high with volume.
    # Do not call the same reversal candle a confirmed breakout.
    confirmation = (
        trend_ok and rsi_ok and volume_ok
        and float(previous["Close"]) > breakout_level
        and close > float(previous["High"])
    )

    if not watch and not confirmation:
        return None

    reversal_high = float(previous["High"]) if confirmation else high
    swing_low = float(df.tail(10)["Low"].min())
    entry_trigger = reversal_high
    risk_per_share = entry_trigger - swing_low
    target1 = entry_trigger + 2 * risk_per_share if risk_per_share > 0 else np.nan
    target2 = entry_trigger + 3 * risk_per_share if risk_per_share > 0 else np.nan

    return {
        "Symbol": symbol,
        "Date": str(df.index[-1].date()),
        "Close": round(close, 2),
        "ATH_Breakout_Level": round(breakout_level, 2),
        "Rise_After_Breakout_%": round(rise_pct, 2),
        "DMA20": round(dma20, 2),
        "DMA50": round(dma50, 2),
        "RSI14": round(rsi_now, 2),
        "Volume": int(latest["Volume"]),
        "AvgVolume20": int(latest["AvgVol20"]) if pd.notna(latest["AvgVol20"]) else 0,
        "Volume_Ratio": round(vol_ratio, 2),
        "Retest": retest_ok,
        "Bullish_RSI_Divergence": divergence,
        "Bullish_Reversal": reversal_ok,
        "Reversal_Candle_High": round(reversal_high, 2),
        "Swing_Low_SL_Reference": round(swing_low, 2),
        "Entry_Trigger": round(entry_trigger, 2),
        "Target_1_RR_1to2": round(target1, 2) if pd.notna(target1) else "",
        "Target_2_RR_1to3": round(target2, 2) if pd.notna(target2) else "",
        "Signal": "BUY CONFIRMATION" if confirmation else "BUY WATCH",
    }


def main():
    parser = argparse.ArgumentParser(description="NSE ATH Retest Swing Scanner")
    parser.add_argument("--limit", type=int, default=None, help="Test only first N symbols")
    parser.add_argument("--sleep", type=float, default=0.25, help="Pause between requests")
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(exist_ok=True)
    symbols = load_symbols(args.limit)
    logging.info("Scanning %d NSE symbols...", len(symbols))

    results = []
    failed = []
    for count, symbol in enumerate(symbols, start=1):
        try:
            hist = download_history(symbol)
            if hist.empty:
                failed.append(symbol)
            else:
                result = analyze_symbol(symbol, hist)
                if result:
                    results.append(result)
        except Exception as exc:
            logging.warning("%s failed: %s", symbol, exc)
            failed.append(symbol)
        if count % 25 == 0:
            logging.info("Processed %d/%d", count, len(symbols))
        time.sleep(args.sleep)

    output = pd.DataFrame(results)
    if not output.empty:
        order = {"BUY CONFIRMATION": 0, "BUY WATCH": 1}
        output["_order"] = output["Signal"].map(order)
        output = output.sort_values(["_order", "Volume_Ratio"], ascending=[True, False])
        output = output.drop(columns="_order")
    date_tag = pd.Timestamp.now().strftime("%Y%m%d")
    csv_path = OUTPUT_DIR / f"nse_swing_scan_{date_tag}.csv"
    output.to_csv(csv_path, index=False)

    failed_path = OUTPUT_DIR / f"failed_symbols_{date_tag}.txt"
    failed_path.write_text("\n".join(failed), encoding="utf-8")

    if output.empty:
        logging.info("No stocks met the complete scanner conditions today.")
    else:
        logging.info("Found %d candidates:", len(output))
        print(output.to_string(index=False))
    logging.info("Saved results: %s", csv_path)
    if failed:
        logging.warning("%d symbols had missing/failed data. See %s", len(failed), failed_path)


if __name__ == "__main__":
    main()
